package LeerArchivo;

public class Main {
    public static void main(String[] args) {
        // Crear instancia de las clases (que necesitemos) para acceder a sus métodos
        ReadChar readCharFichero = new ReadChar();
        // Llamar al método para leer caracteres del fichero
        readCharFichero.readCharMethod();

        // Otros métodos aquí
        // ReadEverything readEverythingFichero = new ReadEverything();
        // readEverythingFichero.leerTodo();


    }
}
